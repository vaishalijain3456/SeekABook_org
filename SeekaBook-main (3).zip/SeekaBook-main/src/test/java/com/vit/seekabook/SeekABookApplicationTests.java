package com.vit.seekabook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeekABookApplicationTests {

    @Test
    void contextLoads() {
    }

}
