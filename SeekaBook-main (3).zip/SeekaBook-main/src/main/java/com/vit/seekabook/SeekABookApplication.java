package com.vit.seekabook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeekABookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeekABookApplication.class, args);
	}

}
