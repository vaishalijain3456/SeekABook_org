package com.vit.seekabook.domain;

public enum UserType {
    Admin,
    User
}
